
function loGin(){
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    if(email == "chris" && password == "chris123"){
        window.location.assign("index.html");
        alert("Login Successfully!");
        
    }
    else{
         alert("Invalid Information ")
         return;
    }
}
