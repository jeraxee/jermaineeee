<?php
    session_start();

    include("config.php");


    if($_SERVER['REQUEST_METHOD'] == "POST") {

        $user = $_POST['username'];
        $pass = $_POST['password'];

        if(!empty($user) && !empty($pass) && !empty($user)) {

            $query = "SELECT * FROM users WHERE username = '$user' LIMIT 1";
            $result = mysqli_query($conn, $query);

            if($result) { 
                if($result && mysqli_num_rows($result) > 0) {

                    $user_data = mysqli_fetch_assoc($result);

                    if($user_data['password'] == $pass) {
                        header("location: port.php");
                        die;
                    }
                }
            }
            echo "<script type='text/javascript'> alert('Login Succesfully!!')</script>";
        }
        else {
            echo "<script type='text/javascript'> alert('Wrong credentials')</script>";
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="login.css">
    <script src="login.js"></script>
    <title>Login </title>
</head>
<style>
body{
    background-color: skyblue;
}
form {
    border: 3px solid #f1f1f1;
    display: flex;

  }
  .wrapper{
    color: #fff;
    padding: 50px;
    margin: 80px;
    width: 30%;
    border: none;
    outline: none;
    border-radius: 20px;
    background-color: rgba(143, 165, 170, 0.11);
    box-shadow: inset -3px -3px rgba(red, green, blue, alpha);
    
    
    
}
  input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }
  
  #logButton {
    background-color: #c54141;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
   
  }
  
  .button{
    opacity: 0.8;
  }
  
  .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
  }
  
  .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
  }
  
  img.avatar {
    width: 40%;
    border-radius: 50%;
  }
  
  .container {
    padding: 16px;
  }
  
  span.psw {
    float: right;
    padding-top: 16px;
  }

  @media screen and (max-width: 300px) {
    span.psw {
      display: block;
      float: none;
    }
    .cancelbtn {
      width: 100%;
    }
  }
</style>
<body>
<form action='' method="post">
        <div class="imgcontainer">
          <img src="img/logo.png" alt="Avatar" class="avatar">
        </div>
      
        <div class="wrapper">
          <label>Username:</label>
          <input type="text" placeholder="Enter Username" name="username">
      
          <label>Password:</label>
          <input type="password" placeholder="Enter Password" name="password">
      
          <button onclick="auth()" type="submit" class="btn"> Login</button>
          <label>
            <input type="checkbox" checked="checked" name="remember"> Remember me
          </label>
        </div>
    </form>

</body>
</html>