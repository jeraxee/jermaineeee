let cartItems = [];
    let total = 0;

    function addToCart(productName, price) {
        cartItems.push({ name: productName, price: price });
        updateCart();
    }

    function updateCart() {
        const cartList = document.getElementById('cart-list');
        const totalElement = document.getElementById('total');
        cartList.innerHTML = '';

        cartItems.forEach(item => {
            const listItem = document.createElement('li');
            listItem.textContent = `${item.name} - $${item.price.toFixed(2)}`;
            cartList.appendChild(listItem);
        });

        calculateTotal();
    }

    function calculateTotal() {
        total = cartItems.reduce((acc, item) => acc + item.price, 0);
        const totalElement = document.getElementById('total');
        totalElement.textContent = total.toFixed(2);
    }

    function checkout() {
        // In a real scenario, this is where you would make a request to the server
        // to process the payment and handle the purchase logic.
        alert(`Total Amount: $${total.toFixed(2)}\nThank you for your purchase!`);
        
        // Clear the cart after purchase
        cartItems = [];
        updateCart();
    }