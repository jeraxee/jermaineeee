<? php 
    include("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Parts Shop</title>
    <link rel="stylesheet" href="shop.css">
    <script src="shop.js"></script>
    
</head>
<body>


<header>
<a href="port.php" class="logo">Back</a>
    <h1>Jermaine's Parts Shop</h1>

</header>

<section>
    <div class="product">
        <img  src="/jermaine/pic/oile.jpg" alt="Engine Oil" onclick="addToCart('Engine Oil', 19.99)">
        <h2>Engine Oil</h2>
        <p>High-quality engine oil for smooth performance.</p>
        <p>$19.99</p>
        
        <!-- <button onclick="addToCart('Engine Oil', 19.99)">Add to Cart</button> -->
    </div>

    <div class="product">
        <img src="/jermaine/pic/asdasd.jpg" alt="Tires" onclick="addToCart('Quality Tires', 50.99)">
        <h2>Tires</h2>
        <p>High-quality Tires for smooth performance.</p>
        <p>$50.99</p>
        
        <!-- <button onclick="addToCart('Quality Tires', 50.99)">Add to Cart</button> -->
    </div>

    <div class="product">
        <img src="/jermaine/pic/brake.jpg" alt="Brake Pads" onclick="addToCart('Brake Pads', 29.99)">
        
        <h2 class="h5">Brake Pads</h2>
        <p>Durable brake pads for effective stopping power.</p>
        <p>$29.99</p>
      
        
        <!-- <button onclick="addToCart('Brake Pads', 29.99)">Add to Cart</button> -->
    </div>
</section>

<div id="cart">
    <h2>Shopping Cart</h2>
    <ul id="cart-list"></ul>
    <p>Total: $<span id="total">0.00</span></p>
    <button onclick="checkout()">Checkout</button>
</div>




</body>
</html>
