<?php 
 
    $conn = mysqli_connect("localhost","root","","jermaine") or die(mysqli_error($conn));

?>