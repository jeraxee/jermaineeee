<? php 
    include("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" a href="port.css">
    <script src="min.js"></script>
    <link rel="icon" type="image/x-icon" href="img/download.png">
    <title>Auto parts</title>
</head>
<body>
<a href="login.php" class="logo">Logout</a>
   <h1>PORTFOLIO</h1>
   <div class="hero">
    <nav>
        <img src="img/logo.png" class="logo">
        <ul>
            <li><a href="cars.php">Parts and Accessories</a></li>
          
        </ul>
    </nav>
    <div class="detel">
        <h1>I'm Jermaine <span>Burao</span></h1>
        <p>This is my official Portfolio website
        </p>
        <!-- <input type="button" value="Parts and Accessories"><a href="http://"></a> -->
    </div>

</body>
</html>
