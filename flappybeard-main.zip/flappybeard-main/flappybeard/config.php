
<?php 
 
    $conn = mysqli_connect("localhost","root","","flappybeard") or die(mysqli_error($conn));

?>